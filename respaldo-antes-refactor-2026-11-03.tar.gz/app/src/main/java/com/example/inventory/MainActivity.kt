package com.example.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.example.inventory.data.database.AppDatabase
import com.example.inventory.data.database.DatabaseRepository
import com.example.inventory.screens.MainAppScreen
import com.example.inventory.viewmodels.InventarioViewModel

// Definición de la nueva paleta de colores (Verdes y Amarillos)
val VerdeOscuro = Color(0xFF2E7D32)
val VerdeClaro = Color(0xFF81C784)
val AmarilloAccento = Color(0xFFFBC02D)
val FondoClaro = Color(0xFFF1F8E9)

val TemaInventario = lightColorScheme(
    primary = VerdeOscuro,
    primaryContainer = VerdeClaro,
    secondary = AmarilloAccento,
    background = FondoClaro,
    surface = FondoClaro,
    surfaceVariant = Color(0xFFC8E6C9),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "inventario.db"
        )
            .fallbackToDestructiveMigration(dropAllTables = true)
            .build()

        val repository = DatabaseRepository(db.inventarioDao())

        val viewModelFactory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return InventarioViewModel(repository) as T
            }
        }

        setContent {
            MaterialTheme(colorScheme = TemaInventario) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    val viewModel: InventarioViewModel = viewModel(factory = viewModelFactory)
                    MainAppScreen(viewModel)
                }
            }
        }
    }
}