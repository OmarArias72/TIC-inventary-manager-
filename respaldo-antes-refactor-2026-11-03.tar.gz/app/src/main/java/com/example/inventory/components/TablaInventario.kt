package com.example.inventory.components

class TablaInventario {
}