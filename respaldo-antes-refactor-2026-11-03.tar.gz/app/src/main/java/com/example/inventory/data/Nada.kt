package com.example.inventory.data

class Nada {
}