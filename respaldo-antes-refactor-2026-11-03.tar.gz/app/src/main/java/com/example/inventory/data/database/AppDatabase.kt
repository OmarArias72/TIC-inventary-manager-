package com.example.inventory.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.inventory.data.models.*

@Database(
    entities = [
        ArticuloEntity::class,
        MarcaEntity::class,
        ModeloEntity::class,
        EquipoEntity::class,
        EquipoComputoEntity::class
    ],
    version = 6, // Incrementado a 6
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun inventarioDao(): InventarioDao
}