package com.example.inventory.data.database

import com.example.inventory.data.models.*
import com.example.inventory.data.models.ItemInventario

class DatabaseRepository(private val dao: InventarioDao) {

    // 1. OBTENER TODOS
    suspend fun obtenerTodos(): List<ItemInventario> {
        val equiposCompletos = dao.obtenerEquiposCompletosSync()
        return equiposCompletos.map { completo ->
            ItemInventario(
                idPosicion = completo.id_posicion, // Mapeamos el ID
                noInventario = completo.inventario,
                noSerie = completo.serie ?: "",
                articulo = completo.nombre_articulo,
                marca = completo.nombre_marca,
                modelo = completo.nombre_modelo,
                observacion = completo.caracteristicas ?: "",
                ubicacion = completo.ubicacion ?: "", // Recuperamos la ubicación
                estado = completo.estado,
                fechaRegistro = completo.fecha_registro
            )
        }
    }

    // ACTUALIZAR (Refactorizado)
    suspend fun actualizarItem(item: ItemInventario) {
        val inventarioLimpio = item.noInventario.trim()
        if (inventarioLimpio.isEmpty()) return
        guardarRelacionesYEquipo(item, inventarioLimpio, SyncState.MODIFICADO_OFFLINE, true)
    }

    // INSERTAR
    suspend fun insertarItem(item: ItemInventario): Long {
        val inventarioLimpio = item.noInventario.trim()
        if (inventarioLimpio.isEmpty()) return -1
        if (dao.existeNumeroInventario(inventarioLimpio) > 0) return -1
        guardarRelacionesYEquipo(item, inventarioLimpio, SyncState.CREADO_OFFLINE, false)
        return 1
    }

    // 4. ELIMINAR
    suspend fun eliminarItem(inventario: String) {
        dao.eliminarEquipo(inventario)
    }

    // --- FUNCIÓN AUXILIAR ---
    private suspend fun guardarRelacionesYEquipo(
        item: ItemInventario,
        inventario: String,
        estadoSync: SyncState,
        esActualizacion: Boolean
    ) {
        val nomArticulo = item.articulo.trim().ifBlank { "SIN ARTICULO" }.uppercase()
        val nomMarca = item.marca.trim().ifBlank { "SIN MARCA" }.uppercase()
        val nomModelo = item.modelo.trim().ifBlank { "SIN MODELO" }.uppercase()

        dao.insertarArticulo(ArticuloEntity(nombre_articulo = nomArticulo))
        val idArt = dao.obtenerIdArticulo(nomArticulo) ?: 0
        dao.insertarMarca(MarcaEntity(nombre_marca = nomMarca))
        val idMar = dao.obtenerIdMarca(nomMarca) ?: 0
        dao.insertarModelo(ModeloEntity(id_marca = idMar, nombre_modelo = nomModelo))
        val idMod = dao.obtenerIdModelo(nomModelo, idMar) ?: 0

        if (esActualizacion && item.idPosicion > 0) {
            // Actualización conservando el ID
            dao.actualizarEquipo(
                idPosicion = item.idPosicion,
                nuevoInventario = inventario,
                idArticulo = idArt,
                idModelo = idMod,
                serie = item.noSerie.trim(),
                ubicacion = item.ubicacion.trim(),
                caracteristicas = item.observacion,
                estado = item.estado,
                fechaActualizacion = System.currentTimeMillis(),
                syncState = estadoSync
            )
        } else {
            val equipoEntity = EquipoEntity(
                inventario = inventario,
                id_articulo = idArt,
                id_modelo = idMod,
                serie = item.noSerie.trim(),
                ubicacion = item.ubicacion.trim(), // Guardamos ubicación
                caracteristicas = item.observacion,
                estado = item.estado,
                fecha_registro = item.fechaRegistro,
                sync_state = estadoSync
            )
            dao.insertarEquipo(equipoEntity)
        }
    }

    suspend fun existeInventario(noInventario: String): Boolean {
        return dao.existeNumeroInventario(noInventario) > 0
    }
}