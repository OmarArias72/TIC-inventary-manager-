package com.example.inventory.data.database

import androidx.room.*
import com.example.inventory.data.models.*

// POJO auxiliar para extraer la información unida de múltiples tablas
data class EquipoCompleto(
    val id_posicion: Int,
    val inventario: String,
    val serie: String?,
    val nombre_articulo: String,
    val nombre_marca: String,
    val nombre_modelo: String,
    val ubicacion: String?,
    val estado: String,
    val caracteristicas: String?,
    val fecha_registro: Long,
    val sync_state: SyncState
)
@Dao
interface InventarioDao {

    @Query("""
        SELECT e.id_posicion, e.inventario, e.serie, a.nombre_articulo, ma.nombre_marca, mo.nombre_modelo, 
               e.ubicacion, e.estado, e.caracteristicas, e.fecha_registro, e.sync_state
        FROM equipos e
        INNER JOIN articulos a ON e.id_articulo = a.id_articulo
        INNER JOIN modelos mo ON e.id_modelo = mo.id_modelo
        INNER JOIN marcas ma ON mo.id_marca = ma.id_marca
        ORDER BY e.id_posicion ASC 
    """) // Ordenado por id_posicion para no perder el orden nunca
    suspend fun obtenerEquiposCompletosSync(): List<EquipoCompleto>

    // --- CONSULTAS PARA SINCRONIZACIÓN ---
    @Query("SELECT * FROM equipos WHERE sync_state != 'SINCRONIZADO'")
    suspend fun obtenerEquiposPendientesSync(): List<EquipoEntity>

    @Query("UPDATE equipos SET sync_state = 'SINCRONIZADO' WHERE inventario = :inventario")
    suspend fun marcarComoSincronizado(inventario: String)

    // --- VERIFICACIONES Y ELIMINACIÓN ---
    @Query("SELECT COUNT(*) FROM equipos WHERE inventario = :inventario")
    suspend fun existeNumeroInventario(inventario: String): Int

    @Query("DELETE FROM equipos WHERE inventario = :inventario")
    suspend fun eliminarEquipo(inventario: String)

    // --- INSERCIONES DE CATÁLOGOS ---
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarArticulo(articulo: ArticuloEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarMarca(marca: MarcaEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarModelo(modelo: ModeloEntity): Long

    // --- INSERCIÓN / ACTUALIZACIÓN DE EQUIPO ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarEquipo(equipo: EquipoEntity)

    @Query("""
        UPDATE equipos SET 
            inventario = :nuevoInventario, 
            id_articulo = :idArticulo, 
            id_modelo = :idModelo, 
            serie = :serie, 
            ubicacion = :ubicacion, 
            caracteristicas = :caracteristicas, 
            estado = :estado, 
            fecha_actualizacion = :fechaActualizacion,
            sync_state = :syncState
        WHERE id_posicion = :idPosicion
    """)
    suspend fun actualizarEquipo(
        idPosicion: Int, nuevoInventario: String, idArticulo: Int, idModelo: Int,
        serie: String, ubicacion: String, caracteristicas: String, estado: String,
        fechaActualizacion: Long, syncState: SyncState
    )

    // --- CONSULTAS AUXILIARES ---
    @Query("SELECT id_articulo FROM articulos WHERE nombre_articulo = :nombre LIMIT 1")
    suspend fun obtenerIdArticulo(nombre: String): Int?

    @Query("SELECT id_marca FROM marcas WHERE nombre_marca = :nombre LIMIT 1")
    suspend fun obtenerIdMarca(nombre: String): Int?

    @Query("SELECT id_modelo FROM modelos WHERE nombre_modelo = :nombre AND id_marca = :idMarca LIMIT 1")
    suspend fun obtenerIdModelo(nombre: String, idMarca: Int): Int?
}