package com.example.inventory.data.models

// DTOs para la API
data class BusquedaRequest(val termino: String)

data class ArticuloDTO(val idArticulo: Int?, val nombreArticulo: String?)
data class MarcaDTO(val idMarca: Int?, val nombreMarca: String?)
data class ModeloDTO(val idModelo: Int?, val nombreModelo: String?, val marca: MarcaDTO?)

data class EquipoDTO(
    val inventario: String?,
    val serie: String?,
    val articulo: ArticuloDTO?,
    val modelo: ModeloDTO?,
    val estado: String?
)

data class EquipoMovilCreateDTO(
    val noInventario: String,
    val noSerie: String,
    val marca: String,
    val modelo: String,
    val ubicacion: String,
    val observacion: String,
    val estado: String,
    val fechaRegistro: Long
)