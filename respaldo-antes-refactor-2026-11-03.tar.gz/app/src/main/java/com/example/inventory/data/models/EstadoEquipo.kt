package com.example.inventory.data.models

enum class EstadoEquipo(val valor: String) {
    ALTA("ALTA"),
    BAJA("BAJA"),
    MANTENIMIENTO("MANTENIMIENTO");

    companion object {
        fun fromString(valor: String): EstadoEquipo {
            return values().find { it.valor == valor } ?: ALTA
        }
    }
}