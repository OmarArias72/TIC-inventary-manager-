package com.example.inventory.data.models

data class ItemInventario(
    var idPosicion: Int = 0,
    var noInventario: String = "",
    var noSerie: String = "",
    var articulo: String = "",
    var marca: String = "",
    var modelo: String = "",
    var ubicacion: String = "",
    var observacion: String = "",
    var estado: String = "",
    var fechaRegistro: Long = System.currentTimeMillis()
)