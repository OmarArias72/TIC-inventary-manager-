package com.example.inventory.data.models

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class SyncState { SINCRONIZADO, CREADO_OFFLINE, MODIFICADO_OFFLINE }

@Entity(tableName = "articulos")
data class ArticuloEntity(
    @PrimaryKey(autoGenerate = true) val id_articulo: Int = 0,
    val nombre_articulo: String,
    val fecha_actualizacion: Long = System.currentTimeMillis()
)

@Entity(tableName = "marcas")
data class MarcaEntity(
    @PrimaryKey(autoGenerate = true) val id_marca: Int = 0,
    val nombre_marca: String,
    val fecha_actualizacion: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "modelos",
    foreignKeys = [ForeignKey(
        entity = MarcaEntity::class,
        parentColumns = ["id_marca"],
        childColumns = ["id_marca"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("id_marca"), Index(value = ["id_marca", "nombre_modelo"], unique = true)]
)
data class ModeloEntity(
    @PrimaryKey(autoGenerate = true) val id_modelo: Int = 0,
    val id_marca: Int,
    val nombre_modelo: String,
    val fecha_actualizacion: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "equipos",
    foreignKeys = [
        ForeignKey(
            entity = ArticuloEntity::class,
            parentColumns = ["id_articulo"],
            childColumns = ["id_articulo"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ModeloEntity::class,
            parentColumns = ["id_modelo"],
            childColumns = ["id_modelo"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    // Hacemos el campo "inventario" único para mantener la relación externa (foreign keys)
    indices = [Index(value = ["inventario"], unique = true), Index("id_articulo"), Index("id_modelo"), Index("serie")]
)
data class EquipoEntity(
    @PrimaryKey(autoGenerate = true) val id_posicion: Int = 0,
    val inventario: String,
    val id_articulo: Int,
    val id_modelo: Int,
    val serie: String?,
    val ubicacion: String?,
    val caracteristicas: String?,
    val estado: String = "ALTA",
    val fecha_registro: Long = System.currentTimeMillis(),
    val fecha_actualizacion: Long = System.currentTimeMillis(),
    val sync_state: SyncState = SyncState.CREADO_OFFLINE
)

@Entity(
    tableName = "equipos_computo",
    foreignKeys = [ForeignKey(
        entity = EquipoEntity::class,
        parentColumns = ["inventario"],
        childColumns = ["inventario"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["inventario"], unique = true)]
)
data class EquipoComputoEntity(
    @PrimaryKey(autoGenerate = true) val id_equipo_computo: Int = 0,
    val inventario: String,
    val especificaciones_hardware: String?,
    val sistema_operativo: String?,
    val software_instalado: String?,
    val estado_teclado: String?,
    val estado_mouse: String?,
    val estado_monitor: String?,
    val fecha_actualizacion: Long = System.currentTimeMillis(),
    val sync_state: SyncState = SyncState.CREADO_OFFLINE
)