package com.example.inventory.data.network


import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST
import com.example.inventory.data.models.*

interface InventoryApiService {
    @POST("/api/inventory/buscar-por-serie")
    suspend fun buscarPorSerie(@Body request: BusquedaRequest): Response<List<EquipoDTO>>

    @POST("/api/inventory/crear-equipo-movil")
    suspend fun crearEquipoMovil(@Body request: EquipoMovilCreateDTO): Response<EquipoDTO>
}