package com.example.inventory.data.repository

class InventarioRepository {
}