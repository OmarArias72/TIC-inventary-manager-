package com.example.inventory.data.services

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.inventory.data.models.ItemInventario

class ExcelService(private val context: Context) {

    // Función privada para centralizar la creación del documento
    private fun crearWorkbook(lista: List<ItemInventario>): XSSFWorkbook {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("Inventario de Equipos")

        val encabezados = listOf(
            "No. Inventario", "No. Serie", "Marca", "Modelo",
            "Ubicación", "Observación", "Estado", "Fecha de Registro"
        )
        val headerRow = sheet.createRow(0)
        encabezados.forEachIndexed { index, title ->
            headerRow.createCell(index).setCellValue(title)
        }

        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

        lista.forEachIndexed { rowIndex, item ->
            val row = sheet.createRow(rowIndex + 1)
            row.createCell(0).setCellValue(item.noInventario)
            row.createCell(1).setCellValue(item.noSerie)
            row.createCell(2).setCellValue(item.marca)
            row.createCell(3).setCellValue(item.modelo)
            row.createCell(4).setCellValue(item.ubicacion)
            row.createCell(5).setCellValue(item.observacion)
            row.createCell(6).setCellValue(item.estado)
            val fecha = if (item.fechaRegistro > 0) {
                dateFormat.format(Date(item.fechaRegistro))
            } else {
                ""
            }
            row.createCell(7).setCellValue(fecha)
        }

        for (col in encabezados.indices) {
            sheet.setColumnWidth(col, 15 * 256)
        }

        return workbook
    }

    // Exportar y compartir (Lógica anterior)
    fun compartirInventario(lista: List<ItemInventario>) {
        try {
            val workbook = crearWorkbook(lista)
            val file = File(context.cacheDir, "Inventario_Equipos.xlsx")
            FileOutputStream(file).use { workbook.write(it) }
            workbook.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Te comparto el reporte del inventario generado desde la aplicación.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Compartir Inventario"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // NUEVO: Guardar en el almacenamiento del dispositivo usando un Uri
    fun guardarEnUri(lista: List<ItemInventario>, uri: Uri) {
        try {
            val workbook = crearWorkbook(lista)
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                workbook.write(outputStream)
            }
            workbook.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}