package com.example.inventory.data.services

import android.content.Context
import android.net.Uri
import android.graphics.Rect
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

class OcrService {
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val barcodeScanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .build()
    )

    suspend fun procesarImagen(context: Context, imageUri: Uri): Map<String, String> {
        return try {
            val image = InputImage.fromFilePath(context, imageUri)

            val barcodes = barcodeScanner.process(image).await()
            var barcodeValue = ""
            var barcodeRect: Rect? = null
            if (barcodes.isNotEmpty()) {
                val first = barcodes.first()
                barcodeValue = first.rawValue ?: ""
                barcodeRect = first.boundingBox
            }

            val textResult = textRecognizer.process(image).await()
            val allText = textResult.text

            val filteredText = if (barcodeRect != null) {
                val margin = 20
                val left = maxOf(0, barcodeRect.left - margin)
                val right = barcodeRect.right + margin
                val top = barcodeRect.bottom
                val bottom = barcodeRect.bottom + (barcodeRect.height() * 3)

                val roi = Rect(left, top, right, bottom)

                val bloques = textResult.textBlocks
                val lineasFiltradas = bloques
                    .filter { bloque ->
                        bloque.boundingBox?.let { Rect.intersects(it, roi) } == true
                    }
                    .map { it.text }
                    .filter { it.isNotBlank() }

                if (lineasFiltradas.isNotEmpty()) {
                    lineasFiltradas.joinToString("\n")
                } else {
                    allText
                }
            } else {
                allText
            }

            val numeroSerie = extraerNumeroSerie(filteredText, barcodeValue)

            mapOf(
                "codigo_barras" to barcodeValue,
                "numero_serie" to numeroSerie
            )
        } catch (e: Exception) {
            e.printStackTrace()
            mapOf("codigo_barras" to "", "numero_serie" to "")
        }
    }

    private fun extraerNumeroSerie(texto: String, barcodeDetectado: String): String {
        if (barcodeDetectado.isNotBlank()) {
            return barcodeDetectado
        }

        val lineas = texto.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        val candidatos = mutableListOf<String>()

        val ignorar = setOf(
            "UAEM", "VUAEM", "SECRETARIA", "FINANZAS", "ADMINISTRATIVA",
            "CONTROL", "DE", "PATRIMONIO", "UNIVERSITARIO",
            "SERIAL", "PRODUCT", "HP", "NO",
            "ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC",
            "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC",
            "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE",
            "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"
        )

        val patronAnio = Regex("^[0-9]{4}$")

        for (linea in lineas) {
            val partes = linea.split(Regex("[\\s\\-:]+")).map { it.trim() }.filter { it.isNotEmpty() }
            for (parte in partes) {
                if (!parte.matches(Regex("^[A-Za-z0-9]+$"))) continue
                val parteUpper = parte.uppercase()
                if (ignorar.contains(parteUpper)) continue
                if (parteUpper.matches(patronAnio)) continue
                if (parteUpper.matches(Regex("^[A-Z]{3,}$"))) continue
                candidatos.add(parteUpper)
            }
        }

        val mixtos = candidatos.filter { it.any { it.isLetter() } && it.any { it.isDigit() } }
        val soloNumeros = candidatos.filter { it.all { it.isDigit() } }
        val soloLetras = candidatos.filter { it.all { it.isLetter() } }

        return when {
            mixtos.isNotEmpty() -> mixtos.first()
            soloNumeros.isNotEmpty() -> soloNumeros.first()
            soloLetras.isNotEmpty() -> soloLetras.first()
            else -> ""
        }
    }
}