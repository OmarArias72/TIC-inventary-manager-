package com.example.inventory.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageContractOptions
import com.canhub.cropper.CropImageOptions
import com.example.inventory.data.network.ApiClient
import com.example.inventory.data.models.BusquedaRequest
import com.example.inventory.data.models.EquipoMovilCreateDTO
import com.example.inventory.data.services.OcrService
import com.example.inventory.utils.crearUriParaCamara
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActualizarInventarioScreen(onAbrirMenu: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val ocrService = remember { OcrService() }

    // Estados del formulario
    var noInventario by remember { mutableStateOf("") }
    var noSerie by remember { mutableStateOf("") }
    var marca by remember { mutableStateOf("") }
    var modelo by remember { mutableStateOf("") }
    var ubicacion by remember { mutableStateOf("") }
    var observacion by remember { mutableStateOf("") }
    var estadoEquipo by remember { mutableStateOf("ALTA") }
    var expandedEstado by remember { mutableStateOf(false) }
    val opcionesEstado = listOf("ALTA", "BAJA", "MANTENIMIENTO")

    // Estados de configuración e UI
    var deteccionAutomatica by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    // Capturar fecha actual para el registro
    val fechaActual = remember { System.currentTimeMillis() }

    // Función principal: Procesa el OCR y busca en el Backend
    val procesarImagenYBuscar = { uri: Uri ->
        coroutineScope.launch {
            isLoading = true
            try {
                // 1. Extraer texto usando ML Kit
                val datos = ocrService.procesarImagen(context, uri)
                val codDetectado = datos["codigo_barras"] ?: ""

                if (codDetectado.isNotEmpty()) {
                    noInventario = codDetectado
                    Toast.makeText(context, "Código detectado. Buscando en servidor...", Toast.LENGTH_SHORT).show()

                    // 2. Hacer solicitud POST al backend
                    val response = withContext(Dispatchers.IO) {
                        ApiClient.getService().buscarPorSerie(BusquedaRequest(codDetectado))
                    }

                    if (response.isSuccessful && response.body() != null) {
                        val equipos = response.body()!!
                        if (equipos.isNotEmpty()) {
                            val equipoEncontrado = equipos.first() // Tomamos el primer resultado

                            // 3. Autocompletar el formulario
                            noSerie = equipoEncontrado.serie ?: ""
                            marca = equipoEncontrado.modelo?.marca?.nombreMarca ?: ""
                            modelo = equipoEncontrado.modelo?.nombreModelo ?: ""
                            estadoEquipo = equipoEncontrado.estado ?: "ALTA"

                            Toast.makeText(context, "Datos cargados correctamente", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Equipo no encontrado en el catálogo", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(context, "Error en el servidor: ${response.code()}", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "No se pudo detectar el código", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Error de red o procesamiento", Toast.LENGTH_SHORT).show()
            } finally {
                isLoading = false
            }
        }
    }

    // Launchers de la cámara y galería con soporte para recorte con rotación
    val cropWithRotationLauncher = rememberLauncherForActivityResult(CropImageContract()) { result ->
        if (result.isSuccessful) {
            result.uriContent?.let { procesarImagenYBuscar(it) }
        } else {
            result.error?.printStackTrace()
            Toast.makeText(context, "Error al recortar o girar la imagen", Toast.LENGTH_SHORT).show()
        }
    }

    val cropImageLauncher = rememberLauncherForActivityResult(CropImageContract()) { result ->
        if (result.isSuccessful) result.uriContent?.let { procesarImagenYBuscar(it) }
    }

    val automaticCameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && imageUri != null) procesarImagenYBuscar(imageUri!!)
    }

    val automaticGalleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            // Con detección automática, abrir recortador con rotación
            if (deteccionAutomatica) {
                val options = CropImageContractOptions(
                    uri = uri,
                    cropImageOptions = CropImageOptions(
                        allowRotation = true,
                        allowFlipping = true,
                        activityTitle = "Ajusta y recorta la imagen"
                    )
                )
                cropWithRotationLauncher.launch(options)
            } else {
                procesarImagenYBuscar(uri)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            if (deteccionAutomatica) {
                val uri = crearUriParaCamara(context)
                imageUri = uri
                automaticCameraLauncher.launch(uri)
            } else {
                cropImageLauncher.launch(CropImageContractOptions(
                    uri = null,
                    cropImageOptions = CropImageOptions(
                        imageSourceIncludeGallery = false,
                        imageSourceIncludeCamera = true
                    )
                ))
            }
        } else {
            Toast.makeText(context, "Se requiere permiso de cámara", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Actualizar Inventario") },
                navigationIcon = {
                    IconButton(onClick = onAbrirMenu) {
                        Icon(Icons.Default.Menu, contentDescription = "Menú")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            if (isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            // --- SECCIÓN DE ESCÁNER OCR ---
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Escáner OCR para Autocompletado", fontWeight = FontWeight.Bold)

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(checked = deteccionAutomatica, onCheckedChange = { deteccionAutomatica = it })
                        Text("Detección Automática (Sin Recortar)", style = MaterialTheme.typography.bodyMedium)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Button(
                            onClick = {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                    if (deteccionAutomatica) {
                                        val uri = crearUriParaCamara(context)
                                        imageUri = uri
                                        automaticCameraLauncher.launch(uri)
                                    } else {
                                        cropImageLauncher.launch(CropImageContractOptions(
                                            uri = null,
                                            cropImageOptions = CropImageOptions(
                                                imageSourceIncludeGallery = false,
                                                imageSourceIncludeCamera = true
                                            )
                                        ))
                                    }
                                } else {
                                    permissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            },
                            enabled = !isLoading
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Cámara")
                            Spacer(Modifier.width(8.dp))
                            Text("Escanear")
                        }

                        Button(
                            onClick = {
                                if (deteccionAutomatica) {
                                    automaticGalleryLauncher.launch("image/*")
                                } else {
                                    cropImageLauncher.launch(CropImageContractOptions(
                                        uri = null,
                                        cropImageOptions = CropImageOptions(
                                            imageSourceIncludeGallery = true,
                                            imageSourceIncludeCamera = false
                                        )
                                    ))
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            enabled = !isLoading
                        ) {
                            Icon(Icons.Default.Image, contentDescription = "Galería")
                            Spacer(Modifier.width(8.dp))
                            Text("Galería")
                        }
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // --- FORMULARIO DE DATOS ---
            OutlinedTextField(
                value = noInventario,
                onValueChange = { noInventario = it },
                label = { Text("No. Inventario") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            )

            OutlinedTextField(
                value = noSerie,
                onValueChange = { noSerie = it },
                label = { Text("No. Serie") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            )

            OutlinedTextField(
                value = marca,
                onValueChange = { marca = it },
                label = { Text("Marca") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            )

            OutlinedTextField(
                value = modelo,
                onValueChange = { modelo = it },
                label = { Text("Modelo") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            )

            // Dropdown de Estado
            ExposedDropdownMenuBox(
                expanded = expandedEstado,
                onExpandedChange = { expandedEstado = it }
            ) {
                OutlinedTextField(
                    value = estadoEquipo,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Estado del Equipo") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedEstado) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    enabled = !isLoading
                )
                ExposedDropdownMenu(
                    expanded = expandedEstado,
                    onDismissRequest = { expandedEstado = false }
                ) {
                    opcionesEstado.forEach { opcion ->
                        DropdownMenuItem(
                            text = { Text(opcion) },
                            onClick = {
                                estadoEquipo = opcion
                                expandedEstado = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = ubicacion,
                onValueChange = { ubicacion = it },
                label = { Text("Ubicación") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            )

            OutlinedTextField(
                value = observacion,
                onValueChange = { observacion = it },
                label = { Text("Observaciones") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                enabled = !isLoading
            )

            // Mostrar fecha de registro
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "Fecha de registro:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        formatFecha(fechaActual),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // --- BOTÓN GUARDAR ---
            Button(
                onClick = {
                    if (noInventario.isBlank()) {
                        Toast.makeText(context, "El No. Inventario es obligatorio", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    coroutineScope.launch {
                        isLoading = true
                        try {
                            val request = EquipoMovilCreateDTO(
                                noInventario = noInventario.trim(),
                                noSerie = noSerie.trim(),
                                marca = marca.trim(),
                                modelo = modelo.trim(),
                                ubicacion = ubicacion.trim(),
                                observacion = observacion.trim(),
                                estado = estadoEquipo,
                                fechaRegistro = fechaActual  // Campo agregado
                            )

                            val response = withContext(Dispatchers.IO) {
                                ApiClient.getService().crearEquipoMovil(request)
                            }

                            if (response.isSuccessful) {
                                Toast.makeText(context, "Estado actualizado exitosamente", Toast.LENGTH_SHORT).show()
                                // Limpiar campos después de guardar
                                noInventario = ""
                                noSerie = ""
                                marca = ""
                                modelo = ""
                                ubicacion = ""
                                observacion = ""
                                estadoEquipo = "ALTA"
                            } else {
                                Toast.makeText(context, "Fallo al actualizar: ${response.code()}", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Error conectando al servidor", Toast.LENGTH_SHORT).show()
                        } finally {
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = !isLoading
            ) {
                Text("Guardar Cambios")
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// --- FUNCIONES AUXILIARES ---
private fun formatFecha(timestamp: Long): String {
    return if (timestamp > 0) {
        java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date(timestamp))
    } else {
        ""
    }
}