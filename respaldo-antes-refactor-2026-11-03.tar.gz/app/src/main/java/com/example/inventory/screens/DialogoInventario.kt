package com.example.inventory.screens

class DialogoInventario {
}