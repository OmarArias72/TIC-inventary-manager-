package com.example.inventory.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageContractOptions
import com.canhub.cropper.CropImageOptions
import com.example.inventory.data.models.ItemInventario
import com.example.inventory.data.services.OcrService
import com.example.inventory.data.services.ExcelService
import com.example.inventory.utils.crearUriParaCamara
import com.example.inventory.viewmodels.InventarioViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- PANTALLA PRINCIPAL DE INVENTARIO ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventarioScreen(viewModel: InventarioViewModel, onAbrirMenu: () -> Unit) {
    val context = LocalContext.current
    val excelService = remember { ExcelService(context) }

    var mostrarDialogo by remember { mutableStateOf(false) }
    var itemSeleccionado by remember { mutableStateOf<ItemInventario?>(null) }
    var inventarioAEliminar by remember { mutableStateOf<String?>(null) }

    // --- NUEVO: Estados para la exportación ---
    var mostrarDialogoExportar by remember { mutableStateOf(false) }
    var itemsAExportar by remember { mutableStateOf<List<ItemInventario>>(emptyList()) }

    // --- NUEVO: Launcher para guardar el documento en el almacenamiento interno ---
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        if (uri != null) {
            excelService.guardarEnUri(itemsAExportar, uri)
            Toast.makeText(context, "Archivo guardado exitosamente", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Inventario con OCR") },
                navigationIcon = {
                    IconButton(onClick = onAbrirMenu) {
                        Icon(Icons.Default.Menu, contentDescription = "Abrir Menú")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            BottomAppBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = {
                            itemSeleccionado = ItemInventario(
                                idPosicion = 0,
                                fechaRegistro = System.currentTimeMillis()
                            )
                            mostrarDialogo = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        )
                    ) {
                        Text("Agregar Fila")
                    }
                    Button(
                        onClick = {
                            if (viewModel.filas.isNotEmpty()) {
                                mostrarDialogoExportar = true // Abre el diálogo de exportación
                            } else {
                                Toast.makeText(context, "No hay datos para exportar", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Exportar a XLSX")
                    }
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            if (viewModel.filas.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No hay registros en la tabla.\nPresiona 'Agregar Fila' para comenzar.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                TablaInventario(
                    items = viewModel.filas,
                    onEliminar = { noInventario -> inventarioAEliminar = noInventario },
                    onEditar = { item ->
                        itemSeleccionado = item.copy()
                        mostrarDialogo = true
                    }
                )
            }
        }

        // --- DIÁLOGOS ---
        if (mostrarDialogo && itemSeleccionado != null) {
            DialogoInventario(
                itemInicial = itemSeleccionado!!,
                onDismiss = {
                    mostrarDialogo = false
                    itemSeleccionado = null
                },
                onGuardar = { itemGuardado ->
                    viewModel.guardarFila(itemGuardado, itemSeleccionado!!.noInventario)
                    mostrarDialogo = false
                    itemSeleccionado = null
                }
            )
        }

        if (inventarioAEliminar != null) {
            AlertDialog(
                onDismissRequest = { inventarioAEliminar = null },
                title = { Text("Confirmar eliminación") },
                text = {
                    Text("¿Estás seguro de eliminar el registro con inventario '$inventarioAEliminar'?")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.eliminarFila(inventarioAEliminar!!)
                            inventarioAEliminar = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Eliminar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { inventarioAEliminar = null }) {
                        Text("Cancelar")
                    }
                }
            )
        }

        // --- NUEVO: DIÁLOGO DE EXPORTACIÓN ---
        if (mostrarDialogoExportar) {
            DialogoExportar(
                onDismiss = { mostrarDialogoExportar = false },
                onExportar = { fechaInicio, fechaFin, accion ->
                    val listaFiltrada = if (fechaInicio != null && fechaFin != null) {
                        // Sumamos 86399999 milisegundos para incluir todo el día final (23:59:59)
                        val finDelDia = fechaFin + 86399999L
                        viewModel.filas.filter { it.fechaRegistro in fechaInicio..finDelDia }
                    } else {
                        viewModel.filas
                    }

                    if (listaFiltrada.isEmpty()) {
                        Toast.makeText(context, "No hay registros en el rango seleccionado", Toast.LENGTH_SHORT).show()
                    } else {
                        mostrarDialogoExportar = false
                        if (accion == "GUARDAR") {
                            itemsAExportar = listaFiltrada
                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
                            createDocumentLauncher.launch("Inventario_$timeStamp.xlsx")
                        } else if (accion == "COMPARTIR") {
                            excelService.compartirInventario(listaFiltrada)
                        }
                    }
                }
            )
        }
    }
}

// --- NUEVO: COMPOSABLES DE EXPORTACIÓN Y FILTRO FECHAS ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogoExportar(
    onDismiss: () -> Unit,
    onExportar: (Long?, Long?, String) -> Unit
) {
    val context = LocalContext.current
    var filtrarPorFecha by remember { mutableStateOf(false) }
    var fechaInicio by remember { mutableStateOf<Long?>(null) }
    var fechaFin by remember { mutableStateOf<Long?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Exportar Inventario", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Selecciona los registros a exportar:")

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    RadioButton(selected = !filtrarPorFecha, onClick = { filtrarPorFecha = false })
                    Text("Todos los registros")
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    RadioButton(selected = filtrarPorFecha, onClick = { filtrarPorFecha = true })
                    Text("Filtrar por rango de fecha")
                }

                if (filtrarPorFecha) {
                    SelectorFecha(label = "Fecha Inicio (Desde)", fechaMilis = fechaInicio) { fechaInicio = it }
                    SelectorFecha(label = "Fecha Fin (Hasta)", fechaMilis = fechaFin) { fechaFin = it }
                }
            }
        },
        // Agrupamos todos los botones dentro de confirmButton para controlar el apilamiento vertical
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (filtrarPorFecha && (fechaInicio == null || fechaFin == null)) {
                            Toast.makeText(context, "Selecciona el rango de fechas", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (filtrarPorFecha && fechaInicio!! > fechaFin!!) {
                            Toast.makeText(context, "La fecha inicio no puede ser mayor", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onExportar(if (filtrarPorFecha) fechaInicio else null, if (filtrarPorFecha) fechaFin else null, "GUARDAR")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Guardar en dispositivo")
                }

                Button(
                    onClick = {
                        if (filtrarPorFecha && (fechaInicio == null || fechaFin == null)) {
                            Toast.makeText(context, "Selecciona el rango de fechas", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (filtrarPorFecha && fechaInicio!! > fechaFin!!) {
                            Toast.makeText(context, "La fecha inicio no puede ser mayor", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onExportar(if (filtrarPorFecha) fechaInicio else null, if (filtrarPorFecha) fechaFin else null, "COMPARTIR")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Compartir archivo")
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cancelar")
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectorFecha(label: String, fechaMilis: Long?, onFechaSeleccionada: (Long) -> Unit) {
    var mostrarDialogo by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = fechaMilis ?: System.currentTimeMillis())

    if (mostrarDialogo) {
        DatePickerDialog(
            onDismissRequest = { mostrarDialogo = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { onFechaSeleccionada(it) }
                    mostrarDialogo = false
                }) { Text("Aceptar") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogo = false }) { Text("Cancelar") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    OutlinedButton(onClick = { mostrarDialogo = true }, modifier = Modifier.fillMaxWidth()) {
        Text(if (fechaMilis != null) formatFecha(fechaMilis) else label)
    }
}


// --- DIÁLOGO DE INVENTARIO Y TABLA SE MANTIENEN IGUAL (Solo recorté por legibilidad) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogoInventario(
    itemInicial: ItemInventario,
    onDismiss: () -> Unit,
    onGuardar: (ItemInventario) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val ocrService = remember { OcrService() }

    var noInventario by remember { mutableStateOf(itemInicial.noInventario) }
    var noSerie by remember { mutableStateOf(itemInicial.noSerie) }
    var marca by remember { mutableStateOf(itemInicial.marca) }
    var modelo by remember { mutableStateOf(itemInicial.modelo) }
    var ubicacion by remember { mutableStateOf(itemInicial.ubicacion) }
    var observacion by remember { mutableStateOf(itemInicial.observacion) }
    var estado by remember { mutableStateOf(itemInicial.estado.ifBlank { "ALTA" }) }
    var expandedEstado by remember { mutableStateOf(false) }
    var deteccionAutomatica by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val opcionesEstado = listOf("ALTA", "BAJA", "MANTENIMIENTO")
    val fechaActual = remember { System.currentTimeMillis() }
    val esEdicion = itemInicial.idPosicion > 0

    val procesarImagenExtraida = { uri: Uri ->
        coroutineScope.launch {
            isLoading = true
            try {
                val datos = ocrService.procesarImagen(context, uri)
                val codBarras = datos["codigo_barras"]
                if (!codBarras.isNullOrEmpty()) {
                    noInventario = codBarras
                    Toast.makeText(context, "Código detectado: $codBarras", Toast.LENGTH_SHORT).show()
                }
                val numSerie = datos["numero_serie"]
                if (!numSerie.isNullOrEmpty()) {
                    noSerie = numSerie
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Error al procesar la imagen", Toast.LENGTH_SHORT).show()
            } finally {
                isLoading = false
            }
        }
    }

    val cropWithRotationLauncher = rememberLauncherForActivityResult(CropImageContract()) { result ->
        if (result.isSuccessful) {
            result.uriContent?.let { procesarImagenExtraida(it) }
        } else {
            result.error?.printStackTrace()
            Toast.makeText(context, "Error al recortar o girar la imagen", Toast.LENGTH_SHORT).show()
        }
    }

    val cropImageLauncher = rememberLauncherForActivityResult(CropImageContract()) { result ->
        if (result.isSuccessful) {
            result.uriContent?.let { procesarImagenExtraida(it) }
        } else {
            result.error?.printStackTrace()
            Toast.makeText(context, "Error al procesar recorte", Toast.LENGTH_SHORT).show()
        }
    }

    val automaticCameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && imageUri != null) {
            procesarImagenExtraida(imageUri!!)
        } else {
            Toast.makeText(context, "Error al tomar la foto", Toast.LENGTH_SHORT).show()
        }
    }

    val automaticGalleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            if (deteccionAutomatica) {
                val options = CropImageContractOptions(
                    uri = uri,
                    cropImageOptions = CropImageOptions(
                        allowRotation = true,
                        allowFlipping = true,
                        activityTitle = "Ajusta y recorta la imagen"
                    )
                )
                cropWithRotationLauncher.launch(options)
            } else {
                procesarImagenExtraida(uri)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            if (deteccionAutomatica) {
                val uri = crearUriParaCamara(context)
                imageUri = uri
                automaticCameraLauncher.launch(uri)
            } else {
                cropImageLauncher.launch(
                    CropImageContractOptions(
                        uri = null,
                        cropImageOptions = CropImageOptions(
                            imageSourceIncludeGallery = false,
                            imageSourceIncludeCamera = true
                        )
                    )
                )
            }
        } else {
            Toast.makeText(context, "Se requiere permiso de cámara", Toast.LENGTH_SHORT).show()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (esEdicion) "Editar Registro" else "Nuevo Registro",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isLoading) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                if (!esEdicion) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                "Escáner OCR para Autocompletado",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Checkbox(
                                    checked = deteccionAutomatica,
                                    onCheckedChange = { deteccionAutomatica = it }
                                )
                                Text(
                                    "Detección Automática (Sin Recortar)",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                Button(
                                    onClick = {
                                        if (ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.CAMERA
                                            ) == PackageManager.PERMISSION_GRANTED
                                        ) {
                                            if (deteccionAutomatica) {
                                                val uri = crearUriParaCamara(context)
                                                imageUri = uri
                                                automaticCameraLauncher.launch(uri)
                                            } else {
                                                cropImageLauncher.launch(
                                                    CropImageContractOptions(
                                                        uri = null,
                                                        cropImageOptions = CropImageOptions(
                                                            imageSourceIncludeGallery = false,
                                                            imageSourceIncludeCamera = true
                                                        )
                                                    )
                                                )
                                            }
                                        } else {
                                            permissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    },
                                    enabled = !isLoading
                                ) {
                                    Icon(Icons.Default.CameraAlt, contentDescription = "Cámara")
                                    Spacer(Modifier.width(8.dp))
                                    Text("Escanear")
                                }
                                Button(
                                    onClick = {
                                        if (deteccionAutomatica) {
                                            automaticGalleryLauncher.launch("image/*")
                                        } else {
                                            cropImageLauncher.launch(
                                                CropImageContractOptions(
                                                    uri = null,
                                                    cropImageOptions = CropImageOptions(
                                                        imageSourceIncludeGallery = true,
                                                        imageSourceIncludeCamera = false
                                                    )
                                                )
                                            )
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondary
                                    ),
                                    enabled = !isLoading
                                ) {
                                    Icon(Icons.Default.Image, contentDescription = "Galería")
                                    Spacer(Modifier.width(8.dp))
                                    Text("Galería")
                                }
                            }
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                }

                OutlinedTextField(
                    value = noInventario,
                    onValueChange = { noInventario = it },
                    label = { Text("No. Inventario *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                )

                OutlinedTextField(
                    value = noSerie,
                    onValueChange = { noSerie = it },
                    label = { Text("No. Serie") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                )

                OutlinedTextField(
                    value = marca,
                    onValueChange = { marca = it },
                    label = { Text("Marca") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                )

                OutlinedTextField(
                    value = modelo,
                    onValueChange = { modelo = it },
                    label = { Text("Modelo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                )

                OutlinedTextField(
                    value = ubicacion,
                    onValueChange = { ubicacion = it },
                    label = { Text("Ubicación") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                )

                ExposedDropdownMenuBox(
                    expanded = expandedEstado,
                    onExpandedChange = { expandedEstado = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = estado,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Estado del Equipo") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedEstado)
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        enabled = !isLoading
                    )
                    ExposedDropdownMenu(
                        expanded = expandedEstado,
                        onDismissRequest = { expandedEstado = false }
                    ) {
                        opcionesEstado.forEach { opcion ->
                            DropdownMenuItem(
                                text = { Text(opcion) },
                                onClick = {
                                    estado = opcion
                                    expandedEstado = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = observacion,
                    onValueChange = { observacion = it },
                    label = { Text("Observaciones") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    enabled = !isLoading
                )

                if (esEdicion && itemInicial.fechaRegistro > 0) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Fecha de registro:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                formatFecha(itemInicial.fechaRegistro),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (noInventario.isBlank()) {
                        Toast.makeText(context, "El No. Inventario es obligatorio", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val itemGuardado = ItemInventario(
                        idPosicion = itemInicial.idPosicion,
                        noInventario = noInventario.trim(),
                        noSerie = noSerie.trim(),
                        articulo = itemInicial.articulo,
                        marca = marca.trim(),
                        modelo = modelo.trim(),
                        ubicacion = ubicacion.trim(),
                        observacion = observacion.trim(),
                        estado = estado,
                        fechaRegistro = if (esEdicion) itemInicial.fechaRegistro else fechaActual
                    )
                    onGuardar(itemGuardado)
                },
                enabled = !isLoading
            ) {
                Text(if (esEdicion) "Actualizar" else "Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isLoading) {
                Text("Cancelar")
            }
        }
    )
}

// --- TABLA DE INVENTARIO ---
private val ANCHO_NO_INVENTARIO = 110.dp
private val ANCHO_NO_SERIE = 120.dp
private val ANCHO_MARCA = 100.dp
private val ANCHO_MODELO = 100.dp
private val ANCHO_UBICACION = 120.dp
private val ANCHO_OBSERVACION = 160.dp
private val ANCHO_ESTADO = 100.dp
private val ANCHO_FECHA = 140.dp
private val ANCHO_ACCION = 160.dp

@Composable
private fun TablaInventario(
    items: List<ItemInventario>,
    onEliminar: (String) -> Unit,
    onEditar: (ItemInventario) -> Unit
) {
    val scrollHorizontal = rememberScrollState()

    Column(modifier = Modifier.horizontalScroll(scrollHorizontal)) {
        Row(
            modifier = Modifier
                .background(MaterialTheme.colorScheme.primaryContainer)
                .padding(vertical = 10.dp)
        ) {
            CeldaTabla("No. Inventario", ANCHO_NO_INVENTARIO, esEncabezado = true)
            CeldaTabla("No. Serie", ANCHO_NO_SERIE, esEncabezado = true)
            CeldaTabla("Marca", ANCHO_MARCA, esEncabezado = true)
            CeldaTabla("Modelo", ANCHO_MODELO, esEncabezado = true)
            CeldaTabla("Ubicación", ANCHO_UBICACION, esEncabezado = true)
            CeldaTabla("Observaciones", ANCHO_OBSERVACION, esEncabezado = true)
            CeldaTabla("Estado", ANCHO_ESTADO, esEncabezado = true)
            CeldaTabla("Fecha", ANCHO_FECHA, esEncabezado = true)
            CeldaTabla("Acciones", ANCHO_ACCION, esEncabezado = true)
        }
        HorizontalDivider()

        LazyColumn {
            itemsIndexed(items, key = { _, item -> item.idPosicion }) { index, item ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.background(
                        if (index % 2 == 0) MaterialTheme.colorScheme.surface
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    CeldaTabla(item.noInventario, ANCHO_NO_INVENTARIO)
                    CeldaTabla(item.noSerie, ANCHO_NO_SERIE)
                    CeldaTabla(item.marca, ANCHO_MARCA)
                    CeldaTabla(item.modelo, ANCHO_MODELO)
                    CeldaTabla(item.ubicacion, ANCHO_UBICACION)
                    CeldaTabla(item.observacion, ANCHO_OBSERVACION)
                    Box(
                        modifier = Modifier
                            .width(ANCHO_ESTADO)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        val estadoColor = when (item.estado) {
                            "ALTA" -> MaterialTheme.colorScheme.primary
                            "BAJA" -> MaterialTheme.colorScheme.error
                            "MANTENIMIENTO" -> MaterialTheme.colorScheme.tertiary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Text(
                            text = item.estado,
                            color = estadoColor,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    CeldaTabla(formatFecha(item.fechaRegistro), ANCHO_FECHA)
                    Row(
                        modifier = Modifier.width(ANCHO_ACCION),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { onEditar(item) }) {
                            Text("Editar", color = MaterialTheme.colorScheme.primary)
                        }
                        TextButton(onClick = { onEliminar(item.noInventario) }) {
                            Text("Borrar", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun CeldaTabla(texto: String, ancho: Dp, esEncabezado: Boolean = false) {
    Text(
        text = texto,
        modifier = Modifier
            .width(ancho)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        fontWeight = if (esEncabezado) FontWeight.Bold else FontWeight.Normal,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        color = if (esEncabezado) MaterialTheme.colorScheme.onPrimaryContainer
        else MaterialTheme.colorScheme.onSurface
    )
}

private fun formatFecha(timestamp: Long): String {
    return if (timestamp > 0) {
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            .format(Date(timestamp))
    } else {
        ""
    }
}