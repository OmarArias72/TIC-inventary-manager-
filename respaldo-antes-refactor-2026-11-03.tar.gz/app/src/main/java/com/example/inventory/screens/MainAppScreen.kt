package com.example.inventory.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.inventory.viewmodels.InventarioViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: InventarioViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    var pantallaActual by remember { mutableStateOf("Registrar inventario") }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Menú Principal",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                HorizontalDivider()

                NavigationDrawerItem(
                    label = { Text("Registrar inventario") },
                    selected = pantallaActual == "Registrar inventario",
                    onClick = {
                        pantallaActual = "Registrar inventario"
                        coroutineScope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Actualizar inventario") },
                    selected = pantallaActual == "Actualizar inventario",
                    onClick = {
                        pantallaActual = "Actualizar inventario"
                        coroutineScope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Actualizar equipos de computo") },
                    selected = pantallaActual == "Actualizar equipos de computo",
                    onClick = {
                        pantallaActual = "Actualizar equipos de computo"
                        coroutineScope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        when (pantallaActual) {
            "Registrar inventario" -> InventarioScreen(
                viewModel = viewModel,
                onAbrirMenu = { coroutineScope.launch { drawerState.open() } }
            )
            "Actualizar inventario" -> ActualizarInventarioScreen(
                onAbrirMenu = { coroutineScope.launch { drawerState.open() } }
            )
            "Actualizar equipos de computo" -> PantallaEnConstruccion(
                titulo = "Actualizar equipos de computo",
                onAbrirMenu = { coroutineScope.launch { drawerState.open() } }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaEnConstruccion(titulo: String, onAbrirMenu: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(titulo) },
                navigationIcon = {
                    IconButton(onClick = onAbrirMenu) {
                        Icon(Icons.Default.Menu, contentDescription = "Menú")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            Text("Pantalla en construcción", color = MaterialTheme.colorScheme.secondary)
        }
    }
}