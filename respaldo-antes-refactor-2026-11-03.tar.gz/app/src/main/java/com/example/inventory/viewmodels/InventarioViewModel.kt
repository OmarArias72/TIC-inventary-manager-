package com.example.inventory.viewmodels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventory.data.database.DatabaseRepository
import com.example.inventory.data.models.ItemInventario
import kotlinx.coroutines.launch

class InventarioViewModel(private val repository: DatabaseRepository) : ViewModel() {
    var filas by mutableStateOf<List<ItemInventario>>(emptyList())
        private set

    init {
        cargarDatos()
    }

    fun cargarDatos() {
        viewModelScope.launch {
            filas = repository.obtenerTodos()
        }
    }

    /**
     * Guarda un item. Si se proporciona oldNoInventario y es diferente al nuevo,
     * se elimina el registro antiguo antes de insertar el nuevo.
     */
    fun guardarFila(item: ItemInventario, oldNoInventario: String? = null) {
        viewModelScope.launch {
            if (item.idPosicion > 0) {
                // Si la posición > 0, es un registro existente que estamos editando
                repository.actualizarItem(item)
            } else {
                repository.insertarItem(item)
            }
            cargarDatos()
        }
    }

    fun eliminarFila(noInventario: String) {
        viewModelScope.launch {
            repository.eliminarItem(noInventario)
            cargarDatos()
        }
    }
}